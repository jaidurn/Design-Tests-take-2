#pragma once
//==========================================================================================
// File Name: EnemyAttackState.h
// Author: Brian Blackmon
// Date Created: 5/31/2019
// Purpose: 
// Holds all the information required for the enemy's attack.
// This information includes attack hitboxes, attack knockback, 
// 
//==========================================================================================
#include "EnemyState.h"
#include "AttachInfo.h"

class EnemyAttackState : public EnemyState
{
public:
	EnemyAttackState(int entityID, float weight, AttackCollision *attack, float knockback );
	virtual ~EnemyAttackState();

	virtual bool canEnter();
	virtual bool canExit();

	virtual void enter();
	virtual void update();
	virtual void exit();

private:
	AttackCollision *m_attack;
	float m_knockback;
};

