#include "Component.h"



Component::Component(componentID ID)
	:m_ID(ID)
{

}


Component::~Component()
{

}
