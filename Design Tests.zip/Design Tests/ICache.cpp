#include "ICache.h"



ICache::ICache()
{
}


ICache::~ICache()
{
}
