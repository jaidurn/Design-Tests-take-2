#include "VelocityComponent.h"



VelocityComponent::VelocityComponent()
	:Component(VELOCITY), m_velocity(0, 0)
{

}


VelocityComponent::~VelocityComponent()
{

}