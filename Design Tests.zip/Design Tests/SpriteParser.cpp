#include "SpriteParser.h"
#include "Texture.h"
#include <iostream>
#include <vector>

SpriteParser::SpriteParser()
{
}


SpriteParser::~SpriteParser()
{
}

void SpriteParser::loadSprite(Texture *texture, int columnNum, int rowNum)
{
	if (texture)
	{

	}
}
