#include "EnemyAttackState.h"



EnemyAttackState::EnemyAttackState()
{
}


EnemyAttackState::~EnemyAttackState()
{
}
