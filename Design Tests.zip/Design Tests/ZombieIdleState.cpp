#include "ZombieIdleState.h"
#include "Rotation.h"

ZombieIdleState::ZombieIdleState(int entityID)
	:IState(entityID)
{

}


ZombieIdleState::~ZombieIdleState()
{

}

void ZombieIdleState::enter()
{

}

void ZombieIdleState::update()
{
}

void ZombieIdleState::exit()
{

}
